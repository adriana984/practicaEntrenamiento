import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  SafeAreaView,
  ScrollView,
  StatusBar,
  FlatList,
  View,
  TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons'
const alumnosData = [
  {
    id: 1,
    nombre: 'Esmeralda Flores',
    correo: 'Esme.perez@example.com',
    telefono: '123-456-7890',
    pasatiempos: ['Ver series', 'Viajar', 'Hacer ejercicio'],
    librosFavoritos: [ 'Coraline','La vida en un minuto', 'Como amarte a ti mismo (Y a veces a los demás)' ],
  },
  {
    id: 2,
    nombre: 'María López',
    correo: 'maria.lopez@example.com',
    telefono: '987-4576-8352',
    pasatiempos: ['Leer', 'Viajar', 'Practicar guitarra'],
    librosFavoritos: ['Orgullo y prejuicio', 'El viaje de los colibris', 'Crónica de una muerte anunciada'],
  },
  {
    id: 3,
    nombre: 'Omar Estrada',
    correo: 'Omar.Estrada@example.com',
    telefono: '768-105-5250',
    pasatiempos: ['Hacer ejercicio', 'Viajar', 'Ver series'],
    librosFavoritos: ['El principito', 'Cien años de soledad', 'Volver a empezar'],
  },
  {
    id: 4,
    nombre: 'Ivan Bandala',
    correo: 'Ivan.Bandala@example.com',
    telefono: '784-222-8033',
    pasatiempos: ['Viajar', 'Ver peliculas', 'Pintar'],
    librosFavoritos: ['El principito', 'El cuervo', 'La historia secreta del mundo'],
  },
  {
    id: 5,
    nombre: 'Daniel Gamez',
    correo: 'Dany.GH@example.com',
    telefono: '890-826-0014',
    pasatiempos: ['Escuchar musica', 'Ver peliculas', 'Jugar futbol'],
    librosFavoritos: ['Volver a empezar', 'Tokio Blues', 'Alas de sangre'],
  },
  {
    id: 6,
    nombre: 'Edith Hernandez',
    correo: 'Edy@example.com',
    telefono: '222-456-2159',
    pasatiempos: ['Escuchar musica', 'Ver peliculas', 'Pintar'],
    librosFavoritos: ['La biblioteca de la medianoche', 'Romper el circulo', 'El poder del ahora'],
  },
];

type ItemProps = { title: string };

const Item = ({ title }: ItemProps) => (
  <View style={styles.Text}>
    <Text>{title}</Text>
  </View>
);

const App = () => {
  const [selectedAlumno, setSelectedAlumno] = useState(null);

  const handleSelectAlumno = (alumno) => {
    setSelectedAlumno(alumno);
  };

  const handleRegresar = () => {
    setSelectedAlumno(null); // Limpiar el alumno seleccionado al regresar
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity onPress={() => handleSelectAlumno(item)} style={styles.Text}> 
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Icon
        name='person'
        color='#A879E4'
        size={20}
      />
      <Text style={{ marginLeft: 10 }}>{item.nombre}</Text>
    </View>
  </TouchableOpacity>
);

  return (
    <View style={{  flex:1, color: '#2C3E50',}}>
    <SafeAreaView style={styles.container}>
      <StatusBar  backgroundColor="#B08AE2"/>
      <Text style={styles.headerText}>Bienvenido</Text>
      <Text style={{  fontSize: 14, padding: 10, color: '#2C3E50',}}>Selecciona un usuario: </Text>
       {selectedAlumno ? (
        <>
          <Text style={styles.TitleText}> Datos del usuario:</Text>
          <Text style={styles.Text}>Nombre: {selectedAlumno.nombre}</Text>
          <Text style={styles.Text}>Correo Electrónico: {selectedAlumno.correo}</Text>
          <Text style={styles.Text}>Número de Teléfono: {selectedAlumno.telefono}</Text>

          <Text style={styles.TitleText}>Pasatiempos: </Text>
          <FlatList
            data={selectedAlumno.pasatiempos}
            renderItem={({ item }) => <Item title={item} />}
            keyExtractor={(item) => item}
          />
          <Text style={styles.TitleText}>Libros Favoritos: </Text>
          <FlatList 
            data={selectedAlumno.librosFavoritos}
            renderItem={({ item }) => <Item title={item} />}
            keyExtractor={(item) => item}
          />
          <TouchableOpacity onPress={handleRegresar} style={styles.regresarButton}>
            <Text style={{color: 'white'}}> Regresar </Text>
          </TouchableOpacity>
        </>
      ) : (
        <FlatList
          data={alumnosData}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
        />
      )}
    </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:'#fff',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    paddingVertical: 10,
    color: '#A879E4',
    fontFamily: 'georgia',
    fontWeight: 'bold'
  },
  Text: {
    fontSize: 14,
    padding: 10,
    borderBottomWidth: 1,
    paddingVertical: 14,
    borderBottomColor: '#CCCCCC'
  },
  TitleText: {
    fontSize: 14,
    fontWeight: 'bold',
    padding: 10,
    paddingVertical: 11,
    textAlign: 'center',
  },
  regresarButton: {
    backgroundColor: '#A879E4',
    padding: 10,
    margin: 10,
    borderRadius: 5,
    alignItems: 'center',
  }
});

export default App;