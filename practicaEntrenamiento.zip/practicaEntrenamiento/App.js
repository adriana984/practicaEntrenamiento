/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import { View } from 'react-native';
import App from './src/components/Home';

export default function AppWrapper() {
  return (
    <View style={{ flex: 1 }}>
      <App />
    </View>
  );
}